import cowsay
print(cowsay.get_output_string('trex', 'Hello (extinct) World'))